package model;


import javax.persistence.*;
import java.util.*;


@Entity
@Table(name = "projects", schema = "", catalog = "sql_task2")
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "proj_name")
    private String name;

    @Column(name = "proj_cost")
    private int cost;

    @Column(name = "comp_id")
    private int companyId;

    @Column(name = "cust_id")
    private int customerId;


    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "projects")
    private Collection<Developer> developers;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Collection<Developer> getDevelopers() {
        return developers;
    }

    public void setDevelopers(Set<Developer> developers) {
        this.developers = developers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Project project = (Project) o;

        if (id != project.id) return false;
        if (companyId != project.companyId) return false;
        if (customerId != project.customerId) return false;
        if (cost != project.cost) return false;
        if (name != null ? !name.equals(project.name) : project.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + companyId;
        result = 31 * result + customerId;
        result = 31 * result + cost;
        return result;
    }

    @Override
    public String toString() {
        return "Project{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", cost=" + cost +
                ", companyId=" + companyId +
                ", customerId=" + customerId +
                '}';
    }

//    @Override
//    public String toString(List<Developer> list) {
//        final StringBuilder sb = new StringBuilder("Project{");
//        sb.append("developersList=").append(developersList);
//        sb.append('}');
//        return sb.toString();
//    }
//
//    public static java.lang.String join(java.util.Collection collection,
//                                        char separator)
}
