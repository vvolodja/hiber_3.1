package model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Set;


@Entity
@Table(name = "developers")
public class Developer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "dev_firstName")
    private String firstName;

    @Column(name = "dev_lastName")
    private String lastName;

    @Column(name = "dev_age")
    private int age;

    @Column(name = "comp_id")
    private int companyID;

    @Column(name = "dev_salary")
    private int salary;

    @ManyToMany
    @JoinTable(name = "developer_project",
    joinColumns = @JoinColumn(name = "developer_id"),
//            referencedColumnName = "dev_id"),
            inverseJoinColumns = @JoinColumn(name = "project_id")
//            , referencedColumnName = "proj_id")
    )
    private Collection<Project> projects;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getCompanyID() {
        return companyID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public Collection<Project> getProjects() {
        return projects;
    }

    public void setProjects(Set<Project> projects) {
        this.projects = projects;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Developer that = (Developer) o;

        if (id != that.id) return false;
        if (age != that.age) return false;
//        if (projectID != that.projectID) return false;
        if (companyID != that.companyID) return false;
        if (salary != that.salary) return false;
        if (firstName != null ? !firstName.equals(that.firstName) : that.firstName != null) return false;
        if (lastName != null ? !lastName.equals(that.lastName) : that.lastName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + age;
//        result = 31 * result + projectID;
        result = 31 * result + companyID;
        result = 31 * result + salary;
        return result;
    }

}
