package dao;

import model.Project;
import org.hibernate.Session;
import util.HibernateUtil;

import java.sql.*;
import java.util.List;

public class ProjectDaoImpl implements ProjectDao {


    public void addProject(Project project) throws SQLException {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        session.save(project);
        session.getTransaction().commit();
    }

    public Project getProject(int id) throws SQLException {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        Project project = new Project();
        session.get(Project.class, id);
        session.getTransaction().commit();

        return project;
    }

    public List<Project> getAllProjectsList( ) throws SQLException {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List<Project> allProjectList = session.createQuery("from Project").list();
        session.getTransaction().commit();

        return allProjectList;
    }

    public void updateProject(Project project) throws SQLException {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        session.update(project);
        session.getTransaction().commit();
    }

    public void removeProject(int id) throws SQLException {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        session.delete(session.get(Project.class, id));
        session.getTransaction().commit();


    }
}
